// Labda_From_Zip.yml用の関数
export const handler = async (event) => {
    const response = {
      statusCode: 200,
      body: JSON.stringify('This Lambda is made from zip file'),
    };
    return response;
  };